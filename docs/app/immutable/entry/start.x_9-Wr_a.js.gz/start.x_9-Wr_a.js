import{a as t}from"../chunks/entry.96_iiVi7.js";export{t as start};
