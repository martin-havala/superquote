import{a as t}from"../chunks/entry.RB7-4Czp.js";export{t as start};
