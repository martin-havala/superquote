import{a as t}from"../chunks/entry.fmRFMjhA.js";export{t as start};
