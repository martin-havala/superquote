import{a as t}from"../chunks/entry.LhMIjQiT.js";export{t as start};
