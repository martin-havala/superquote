import{a as t}from"../chunks/entry.sHwUr8BG.js";export{t as start};
