import{a as t}from"../chunks/entry.ZrwrBVwE.js";export{t as start};
