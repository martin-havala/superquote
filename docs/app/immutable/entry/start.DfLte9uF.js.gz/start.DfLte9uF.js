import{a as t}from"../chunks/entry.VIJN17o2.js";export{t as start};
