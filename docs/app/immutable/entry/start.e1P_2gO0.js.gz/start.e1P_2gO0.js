import{a as t}from"../chunks/entry.I4XDFfCk.js";export{t as start};
