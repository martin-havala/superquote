import{a as t}from"../chunks/entry.WKJSINtn.js";export{t as start};
